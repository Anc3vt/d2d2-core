
package com.ancevt.d2d2world.world;

import com.ancevt.d2d2.common.PlainRect;
import com.ancevt.d2d2.display.Color;
import com.ancevt.d2d2.event.Event;

public class Overlay extends PlainRect {

    private static final Color COLOR = Color.BLACK;
    public static final int STATE_IN = 0;
    public static final int STATE_BLACK = 1;
    public static final int STATE_OUT = 2;
    public static final int STATE_DONE = 3;

    private static final float ALPHA_SPEED = 0.1f;

    private int state;
    private float alpha;

    public Overlay(float width, float height) {
        setColor(COLOR);
        setSize(width, height);
        setAlpha(0f);
    }

    public void startIn() {
        if(state == STATE_BLACK) return;
        state = STATE_IN;
        removeEventListener(this, Event.EACH_FRAME);
        addEventListener(this, Event.EACH_FRAME, this::eachFrame);
    }

    public void startOut() {
        if(state == STATE_DONE) return;
        state = STATE_OUT;
        removeEventListener(this, Event.EACH_FRAME);
        addEventListener(this, Event.EACH_FRAME, this::eachFrame);
    }

    private void eachFrame(Event event) {
        switch (getState()) {
            case STATE_IN -> {
                alpha += ALPHA_SPEED;
                setAlpha(Math.min(alpha, 1.0f));
                if (alpha >= 1.2f) {
                    setState(STATE_BLACK);
                    removeEventListener(this, Event.EACH_FRAME);
                }
            }
            case STATE_OUT -> {
                alpha -= ALPHA_SPEED;
                setAlpha(Math.max(alpha, 0.0f));
                if (alpha <= -0.2f) {
                    setState(STATE_DONE);
                    removeEventListener(this, Event.EACH_FRAME);
                }
            }
        }
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
        onStateChanged(state);
    }

    public void onStateChanged(int state) {
        dispatchEvent(Event.builder()
                .type(Event.CHANGE)
                .build());
    }
}
